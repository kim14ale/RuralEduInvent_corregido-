#define MAX_EQUIPOS 50
#define MAX_NOMBRE 50

void agregarEquipo(char [MAX_EQUIPOS][MAX_NOMBRE], int [MAX_EQUIPOS], int [MAX_EQUIPOS], int [MAX_EQUIPOS], int [MAX_EQUIPOS], float [MAX_EQUIPOS], int* );
void mostrarInventario(char [MAX_EQUIPOS][MAX_NOMBRE], int [MAX_EQUIPOS], int [MAX_EQUIPOS], int [MAX_EQUIPOS], int [MAX_EQUIPOS], float [MAX_EQUIPOS], int );
void calcularInversionTotal(char [MAX_EQUIPOS][MAX_NOMBRE], int [MAX_EQUIPOS], int [MAX_EQUIPOS], float [MAX_EQUIPOS], int );
int mostrarMenu();

